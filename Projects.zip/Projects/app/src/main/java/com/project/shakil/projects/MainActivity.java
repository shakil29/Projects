package com.project.shakil.projects;

import android.database.Cursor;
import android.os.AsyncTask;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private Button loadMore;
    private TextView firstName, lastName;
    private ImageView proImage, tickImage;
    RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initialize();

        clicklistener();

        LoadContactsAsycn lca = new LoadContactsAsycn();
        lca.execute();
    }

    public void initialize(){

        loadMore = (Button) findViewById(R.id.loadMore);
        firstName = (TextView) findViewById(R.id.myName);
        lastName = (TextView) findViewById(R.id.myName1);
        proImage = (ImageView) findViewById(R.id.profile_image);
        tickImage = (ImageView) findViewById(R.id.tick);

        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
    }

    public void clicklistener(){

    }

    class LoadContactsAsycn extends AsyncTask<Void, Void, ArrayList<String>>{

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }



        @Override
        protected ArrayList<String> doInBackground(Void... params) {
            ArrayList<String> contacts = new ArrayList<String>();

            Cursor c = getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null,
                    null, null, null);
            while(c.moveToNext()){
                String contactName = c.getString(c.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));

                String phnNumber = c.getString(c.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));

                contacts.add(contactName+ ":" + phnNumber);
            }

            c.close();

            return contacts;
        }

        @Override
        protected void onPostExecute(ArrayList<String> contacts) {
            super.onPostExecute(contacts);

            ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                    getApplicationContext(), R.layout.text, contacts
            );

            recyclerView.setAdapter(adapter);
        }
    }
}
